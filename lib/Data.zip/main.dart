import 'package:abfifteen/fetchData.dart';
import 'package:abfifteen/tabbar.dart';
import 'package:abfifteen/userInfo.dart';
import 'package:flutter/material.dart';

// void main() {
//   runApp(
//     MaterialApp(
//     title: 'tab',
//     debugShowCheckedModeBanner: false,
//     home: DefaultTabController(
//       length: 3,
//       child: Scaffold(
//         appBar: AppBar(
//           actions: [
//             Padding(
//               padding: const EdgeInsets.all(18.0),
//               child: Icon(Icons.notifications),
//             )
//           ],
//           title: Center(child: Text("data")),
//           bottom: TabBar(tabs: [
//             Text("yellow"),
//             Text("black"),
//             Text("blue"),
//           ]),
//         ),
//         body: TabBarView(children: [
//           Center(child: Text("data")),
//           Center(child: Text("hello")),
//           Center(child: Text("ok")),
//         ]),
//       ),
//     ),
//   ));
// }

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Tab bar practice',
    home: fetchData(),
  ));
}

class tabBarPractice extends StatelessWidget {
  const tabBarPractice({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: Text("Tab Bar With Image"),
          bottom: TabBar(tabs: [
            Text("1"),
            Text("2"),
            Text("3"),
            Text("4"),
          ]),
        ),
        body: TabBarView(children: [
          Text("1"),
          Text("2"),
          Text("3"),
          Text("4"),
        ]),
      ),
    );
  }
}
