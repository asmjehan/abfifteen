import 'package:flutter/material.dart';

class fetchData2 extends StatelessWidget {
  fetchData2({Key? key}) : super(key: key);
  List letters = [
    'a',
    'b',
    'c',
    'd',
    'e',
    'f',
    'g',
    'h',
    'i',
    'j',
    'k',
    'l',
    'm',
    'n',
    'o',
    'p'
  ];
  @override
  Widget build(BuildContext context) {
    return Container(
        child: ListView.builder(
      itemCount: letters.length,
      itemBuilder: (context, index) {
        return Text(letters[index]);
      },
    ));
  }
}
