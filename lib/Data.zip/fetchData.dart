import 'package:flutter/material.dart';

class fetchData extends StatelessWidget {
  fetchData({Key? key}) : super(key: key);
  List letters = [
    'a',
    'b',
    'c',
    'd',
    'e',
    'f',
    'g',
    'h',
    'i',
    'j',
    'k',
    'l',
    'm',
    'n',
    'o',
    'p'
  ];
  @override
  Widget build(BuildContext context) {
    return Container(
        child: GridView.count(
      crossAxisCount: 3,
      children: List.generate(16, (index) {
        return Container(
          child: Card(
            color: Colors.blue,
            child: Center(
                child: Text(
              letters[index].toString(),
              style: TextStyle(
                  color: Colors.white,
                  fontSize: MediaQuery.of(context).size.width * .05),
            )),
          ),
        );
      }),
    ));
  }
}
